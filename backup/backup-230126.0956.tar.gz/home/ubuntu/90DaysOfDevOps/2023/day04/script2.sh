#!/bin/bash


echo "The input variables are $1 and $2"

