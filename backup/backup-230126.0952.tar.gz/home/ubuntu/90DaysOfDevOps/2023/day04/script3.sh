#!/bin/bash

if [ $1 -gt $2 ]
then
	echo "$1 is the bigger number"
else
	echo "$2 is the bigger number"
fi

