## Introduction - Day 1

This is the day you have to Take this challenge and start your #90DaysOfDevOps with the #TrainWithShubham Community

- Fork this Repo.
- Start with a DevOps Roadmap[https://youtu.be/iOE9NTAG35g]
- Write a LinkedIn post or a small article about your understanding of DevOps
 - What is DevOps
 - What is Automation, Scaling, Infrastructure
 - Why DevOps is Important, etc
 