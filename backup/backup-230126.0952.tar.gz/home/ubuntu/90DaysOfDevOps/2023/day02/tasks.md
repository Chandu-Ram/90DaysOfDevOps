Day 2 Task: Basics linux command

Task: What is the linux command to 
1. Check your present working directory.
2. List all the files or directories including hidden files.
3. Create a nested directory A/B/C/D/E

Note: [Check this file for reference](basic_linux_commands.md)

Check the basic_linux_commands.md file on the same directory day2
